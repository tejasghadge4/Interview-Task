def get_google_drive_link_map():
    return {
        "test1.txt": "https://drive.google.com/file/d/1PfpgCTclrrLFwn5FnK7BQKndzMnXXok4/view?usp=drive_link",
        "test2.txt": "https://drive.google.com/file/d/16CpTDEE_JmH4T0ndSbTXVnTyJ1qDUChn/view?usp=drive_link",
        "test3.txt":"https://drive.google.com/file/d/1D0DlSUzKL4V-a1hdJ02cem7smaqQ03z-/view?usp=drive_link",
        "test4.txt":"https://drive.google.com/file/d/1WkCAYMzb2wa-G4jX2B-ZmY87eAFl9VRQ/view?usp=drive_link",
    }